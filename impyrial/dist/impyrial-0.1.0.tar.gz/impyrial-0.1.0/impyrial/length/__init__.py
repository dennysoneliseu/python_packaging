'''
impyrial.length
===============
Length conversion between imperial units.'''

# This is the __init__.py file for the impyrial/length subpackage

# Import the convert_unit function from the api.py module
from .api import convert_unit